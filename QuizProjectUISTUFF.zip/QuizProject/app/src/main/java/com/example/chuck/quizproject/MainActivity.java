package com.example.chuck.quizproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

//Screen to enter the IP and port to connect to the server
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText port, ip, id;
    Button go;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        port = (EditText)findViewById(R.id.Port);
        ip = (EditText)findViewById(R.id.IP);
        id = (EditText)findViewById(R.id.identifier);
        go = (Button)findViewById(R.id.Go);
        go.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if(view.getId() == go.getId())//User trying to connect to server
        {

        }
    }
}
