package com.example.chuck.quizproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Charles on 4/25/2017.
 * Screen to take QR code picture
 */

public class QRScreen extends AppCompatActivity implements View.OnClickListener {
    Button take;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qr);
        take = (Button)findViewById(R.id.Qr);
        take.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == take.getId())//Take QR code picture
        {

        }
    }


}
