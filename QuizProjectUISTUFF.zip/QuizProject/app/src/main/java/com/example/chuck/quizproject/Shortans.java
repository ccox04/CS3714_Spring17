package com.example.chuck.quizproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

/**
 * Created by chuck on 4/26/2017.
 */

public class Shortans extends AppCompatActivity implements View.OnFocusChangeListener {
    EditText string;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shortans);
        string = (EditText)findViewById(R.id.string);
        string.setOnFocusChangeListener(this);
    }

    @Override
    public void onFocusChange(View view, boolean b) {//The edittext is done editing.

    }
}
