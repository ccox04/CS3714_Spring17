package com.example.chuck.quizproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by chuck on 4/26/2017.
 */

public class MultipleChoice extends AppCompatActivity implements View.OnClickListener{
    Button a,b,c,d,e;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.multiplechoice);
        a = (Button)findViewById(R.id.A);
        b = (Button)findViewById(R.id.B);
        c = (Button)findViewById(R.id.C);
        d = (Button)findViewById(R.id.D);
        e = (Button)findViewById(R.id.E);
        a.setOnClickListener(this);
        b.setOnClickListener(this);
        c.setOnClickListener(this);
        d.setOnClickListener(this);
        e.setOnClickListener(this);
        //Not sure how you getting the answers from teh QR code but need an intent
        Intent intent = getIntent();

    }
    @Override
    public void onClick(View view) {
        if (view.getId() == a.getId())
        {


        }
        else if(view.getId() == b.getId())
        {

        }
        else if(view.getId() == c.getId())
        {

        }
        else if(view.getId() == d.getId())
        {

        }
        else if(view.getId() == e.getId())
        {

        }
    }
}
